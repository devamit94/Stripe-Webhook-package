# Laravel Cashier Package  :

I'm creating a Stripe checkout form process for a single payment, step-by-step.


# Technologies used:

* Laravel 10
* Official Stripe.js with Stripe Elements
* Laravel Cashier 14
* Laravel UI (Bootstrap 4)
* Spatie Laravel Stripe Webhook package